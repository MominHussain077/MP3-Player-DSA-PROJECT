#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Node structure for the binary search tree
struct Mp3Node {
    string fileName;
    string filePath;
    Mp3Node* left;
    Mp3Node* right;

    Mp3Node(const string& fileName, const string& filePath)
        : fileName(fileName), filePath(filePath), left(nullptr), right(nullptr) {}
};

// Binary search tree class for managing MP3 nodes
class Mp3BST {
private:
    Mp3Node* root;

    void addMp3Node(Mp3Node*& node, const string& fileName, const string& filePath) {
        if (!node) {
            node = new Mp3Node(fileName, filePath);
        }
        else if (fileName < node->fileName) {
            addMp3Node(node->left, fileName, filePath);
        }
        else {
            addMp3Node(node->right, fileName, filePath);
        }
    }

    void inOrderTraversal(Mp3Node* node, vector<Mp3Node*>& songList) const {
        if (node) {
            inOrderTraversal(node->left, songList);
            songList.push_back(node);
            inOrderTraversal(node->right, songList);
        }
    }

public:
    Mp3BST() : root(nullptr) {}

    void addMp3(const string& fileName, const string& filePath) {
        addMp3Node(root, fileName, filePath);
    }

    vector<Mp3Node*> getSongList(){
        vector<Mp3Node*> songList;
        inOrderTraversal(root, songList);
        return songList;
    }
};

// Circular doubly linked list class for managing MP3 nodes
class Mp3List {
private:
    Mp3Node* head;
    Mp3Node* current;
    sf::Music music;

public:
    Mp3List() : head(nullptr), current(nullptr) {}

    // Add an MP3 file to the list
    void addMp3(const string& fileName, const string& filePath) {
        Mp3Node* newNode = new Mp3Node(fileName, filePath);

        if (!head) {
            head = newNode;
            head->left = head;
            head->right = head;
            current = head;
        }
        else {
            newNode->right = head;
            newNode->left = head->left;
            head->left->right = newNode;
            head->left = newNode;
        }
    }

    // Play the current MP3
    void playCurrent() {
        if (current) {
            if (!music.openFromFile(current->filePath)) {
                std::cerr << "Failed to load: " << current->fileName << std::endl;
            }
            else {
                music.play();
            }
        }
    }

    // Move to the next MP3 in the list
    void next() {
        if (current) {
            current = current->right;
            stop();
            playCurrent();
        }
    }

    // Move to the previous MP3 in the list
    void prev() {
        if (current) {
            current = current->left;
            stop();
            playCurrent();
        }
    }

    // Stop the playback
    void stop() {
        music.stop();
    }
};

void main() {
    // Create an SFML window
    sf::RenderWindow window(sf::VideoMode(1000, 900), "SFML MP3 Player");
    sf::RectangleShape r, add, exit, co, second;
    r.setSize(sf::Vector2f(1000, 900));
    sf::Texture bc, bk2;
    bc.loadFromFile("ssaa.png");
    r.setTexture(&bc);
    sf::CircleShape play(60);
    play.setPosition(sf::Vector2f(430, 207));

    // Creating new window
    second.setSize(sf::Vector2f(900, 620));
    bk2.loadFromFile("2a.jpg");
    second.setTexture(&bk2);

    // Add and exit buttons
    add.setSize(sf::Vector2f(135, 66));
    add.setPosition(sf::Vector2f(330, 800));
    exit.setSize(sf::Vector2f(135, 66));
    exit.setPosition(sf::Vector2f(490, 800));

    // Create an MP3 list and BST
    Mp3List mp3List;
    Mp3BST mp3BST;

    mp3List.addMp3("song 1", "./Magic.ogg");
    mp3List.addMp3("song 2", "./Pasori.opus");
    mp3List.addMp3("song 3", "./Ravi.opus");
    mp3List.addMp3("song 4", "./sadqa.ogg");
    mp3List.addMp3("song 5", "./diljit.ogg");
    mp3List.addMp3("song 6", "./21.ogg");

    mp3BST.addMp3("song 1", "./Magic.ogg");
    mp3BST.addMp3("song 2", "./Pasori.opus");
    mp3BST.addMp3("song 3", "./Ravi.opus");
    mp3BST.addMp3("song 4", "./sadqa.ogg");
    mp3BST.addMp3("song 5", "./diljit.ogg");
    mp3BST.addMp3("song 6", "./21.ogg");

    // Font
    sf::Font f;
    f.loadFromFile("ff.ttf");
    sf::Text t, t1, t2, TS, TS1, TS2;
    t.setFont(f);
    t.setString("MUSIC ON");
    t.setCharacterSize(36);
    t.setPosition(sf::Vector2f(350, 60));

    sf::Text son1("Play", f, 32);
    son1.setFillColor(sf::Color::Black);
    son1.setPosition(sf::Vector2f(455, 248));

    t1.setFont(f);
    t1.setString("ADD");
    t1.setCharacterSize(28);
    t1.setPosition(sf::Vector2f(370, 820));
    t2.setFont(f);
    t2.setString("EXIT");
    t2.setCharacterSize(28);
    t2.setPosition(sf::Vector2f(530, 820));

    // Mouse functionality
    sf::Mouse click;
    sf::Vector2i m;

    // Main loop
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            else if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::E) {
                    window.close();
                }
                else if (event.key.code == sf::Keyboard::A) {
                    string path_name, song_name;
                    cin >> path_name >> song_name;
                    mp3List.addMp3(song_name, path_name);
                    mp3BST.addMp3(song_name, path_name);
                }
            }
        }

        m.x = click.getPosition().x;
        m.y = click.getPosition().y;
        cout << endl;
        cout << m.x << " " << m.y << endl;

        // Play button
        if (m.x > 900 && m.x < 1022 && m.y > 341 && m.y < 462 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
            sf::RenderWindow new_window(sf::VideoMode(900, 620), "MUSIC");
            sf::Texture t1, t2, t3, t4;
            t1.loadFromFile("purple playbutton.png");
            t2.loadFromFile("prev.jpg");
            t3.loadFromFile("next.jpg");
            t4.loadFromFile("play.jpg");
            sf::CircleShape s(36), s1(25), s2(25);
            s.setTexture(&t1);
            s1.setTexture(&t2);
            s2.setTexture(&t3);

            sf::RectangleShape bar(sf::Vector2f(800, 30));
            bar.setPosition(45, 470);
            bar.setFillColor(sf::Color::Red);
            sf::RectangleShape stop(sf::Vector2f(70, 70));
            stop.setTexture(&t4);
            stop.setPosition(430, 547.5);
            s.setPosition(30, 530);
            s1.setPosition(120, 548);
            s2.setPosition(175, 548);

            vector<Mp3Node*> songList = mp3BST.getSongList();
            auto current = songList.begin();

            while (new_window.isOpen()) {
                sf::Event event2;
                while (new_window.pollEvent(event2)) {
                    if (event2.type == sf::Event::Closed) {
                        new_window.close();
                        mp3List.stop();
                    }
                    else if (event2.type == sf::Event::KeyPressed) {
                        if (event2.key.code == sf::Keyboard::Space) {
                            mp3List.playCurrent();
                        }
                        else if (event2.key.code == sf::Keyboard::Right) {
                            mp3List.next();
                        }
                        else if (event2.key.code == sf::Keyboard::Left) {
                            mp3List.prev();
                        }
                        else if (event2.key.code == sf::Keyboard::Enter) {
                            mp3List.stop();
                            new_window.close();
                        }
                    }
                }

                m.x = click.getPosition().x;
                m.y = click.getPosition().y;
                cout << endl;
                cout << m.x << " " << m.y << endl;

                // Next, pause, previous button click
                if (m.x > 550 && m.x < 623 && m.y > 804 && m.y < 878 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    mp3List.playCurrent();
                }

                if (m.x > 639 && m.x < 691 && m.y > 821 && m.y < 873 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    mp3List.prev();
                }

                if (m.x > 695 && m.x < 746 && m.y > 821 && m.y < 873 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    mp3List.next();
                }

                if (m.x > 950 && m.x < 1019 && m.y > 820 && m.y < 892 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    mp3List.stop();
                }

                new_window.clear();
                new_window.draw(second);
                new_window.draw(s);
                new_window.draw(s1);
                new_window.draw(s2);
                new_window.draw(bar);
                new_window.draw(stop);
                new_window.display();
            }
        }

        // Add new music
        play.setOutlineThickness(0);
        add.setOutlineThickness(0);
        add.setFillColor(sf::Color::White);
        t1.setFillColor(sf::Color(sf::Color::Black));
        if (m.x > 800 && m.x < 937 && m.y > 933 && m.y < 995) {
            play.setOutlineThickness(30.5);
            add.setOutlineThickness(7);
            add.setFillColor(sf::Color::Black);
            t1.setFillColor(sf::Color(sf::Color::White));
            if (m.x > 800 && m.x < 937 && m.y > 933 && m.y < 995 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                string path_name, song_name;
                cout << "Enter path of file and song name :" << endl;
                cin >> path_name;
                cin >> song_name;
                mp3List.addMp3(song_name, path_name);
                mp3BST.addMp3(song_name, path_name);
            }
        }

        exit.setOutlineThickness(0);
        exit.setFillColor(sf::Color::White);
        t2.setFillColor(sf::Color(sf::Color::Black));
        if (m.x > 959 && m.x < 1097 && m.y > 933 && m.y < 995) {
            exit.setOutlineThickness(7);
            exit.setFillColor(sf::Color::Black);
            t2.setFillColor(sf::Color(sf::Color::White));
            if (m.x > 959 && m.x < 1097 && m.y > 933 && m.y < 995 && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                window.close();
            }
        }

        window.clear();

        // Draw UI elements or update visuals
        window.draw(r);
        window.draw(play);
        window.draw(add);
        window.draw(exit);
        window.draw(t);
        window.draw(t1);
        window.draw(t2);
        window.draw(son1);

        window.display();
    }

    return;
}